# Catalogo de filmes com HTML e CSS
Projeto desenvolvido no curso online DevSuperior, com fundamentos básicos de programação web. Catálogo de filmes/séries com HTML e CSS.
## 🔹Imagens:
- Página inicial, exibindo todos os filmes e séries;
<img width="70%" alt="Tela Inicial" src="https://i.pinimg.com/originals/e4/f5/52/e4f55243296d02f1d5ee328957d1e738.png" />

 
## 
- Segunda página, possibilidade de avaliar;

<img width="70%" alt="Segunda Tela" src="https://i.pinimg.com/originals/16/72/f4/1672f44851f0702c30b221dadc8cecc3.png" />

<a href="https://discord.com/channels/@LuizLich#5096"><img img width = '32px' align= 'center' src="https://logodownload.org/wp-content/uploads/2017/11/discord-logo-7-1.png"></a>
<a href = 'https://www.github.com/LuizLich'> <img width = '32px' align= 'center' src="https://icon-library.com/images/github-icon-white/github-icon-white-6.jpg"/></a>
<a href = 'https://www.instagram.com/luiz.lewiss/'> <img width = '32px' align= 'center' src="https://www.freepnglogos.com/uploads/instagram-icon-png/instagram-icon-suzem-limited-make-known-20.png"/></a>
<a href = 'https://www.linkedin.com/in/luiz-felipe-terra-da-silva/'> <img width = '32px' align= 'center' src="https://cdn-icons-png.flaticon.com/512/179/179330.png"/></a> 
<a href = 'https://br.pinterest.com/luizlewiss/_saved/'> <img width = '32px' align= 'center' src="https://cdn-icons-png.flaticon.com/512/145/145808.png"/></a> 
<a href = 'https://twitter.com/theluizlewiss'> <img width = '32px' align= 'center' src="https://cdn4.iconfinder.com/data/icons/social-media-icons-the-circle-set/48/twitter_circle-512.png"/></a> 

<p>📫 Email: luiz.terrasilva27@gmail.com</p>
